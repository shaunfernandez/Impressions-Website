<!DOCTYPE html>
<head>
  <meta charset="utf-8">
  <title>SDS Book Registration</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<style>
body  {
    background-image: url("Aqua_Blue.jpg");
	background-repeat:no-repeat;
    background-size:cover;
}
</style>
<body>
  <section class="container">
    <div class="login">
      <h1>Registration Failed</h1>
      <h3>Redirecting to Registration Page...</h1>

	<meta http-equiv="refresh" content="2;url=register.php" />


	</div>
	  

  </section>

</body>
</html>